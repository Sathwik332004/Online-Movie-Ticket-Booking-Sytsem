/**
 * 
 */
/**
 * 
 */
module Movie_Ticket_Booking_System {
	requires java.desktop;
	requires java.sql;
}